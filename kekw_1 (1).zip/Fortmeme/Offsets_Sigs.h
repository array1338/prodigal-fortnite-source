#pragma once
#include "Prodigal_Common.h"
#include "FortUpdater.h"


#define RVA(addr, size) ((PBYTE)((UINT_PTR)(addr) + *(PINT)((UINT_PTR)(addr) + ((size) - sizeof(INT))) + (size)))



namespace offsets
{
	//------OFFSET DUMP------
	DWORD LOST = 0x4CAF6C0;
	DWORD FREE = 0x3486060;
	DWORD PROJECTWORLDTOSCREEN = 0x4FC62F0;
	DWORD BONEMATRIX = 0x4C7C620;
	DWORD GETACTORBOUNDS = 0x4AB7220;
	DWORD GETNAME = 0x4DFD6C0;

	DWORD PersistentLevel = 0x30;
	DWORD GameInstance = 0x180;
	DWORD LocalPlayersArray = 0x38;
	DWORD AcknowledgedPawn = 0x2A0;
	DWORD PlayerState = 0x240;
	DWORD TeamIndex = 0xEB8;
	DWORD Mesh = 0x280;
	DWORD CustomTimeDilation = 0x98;
	DWORD RootComponent = 0x130;
	DWORD RelativeLocation = 0x11C;
	DWORD ComponentVelocity = 0x140;
	//------OFFSET DUMP------

	DWORD ActorArray = 0x98;
	DWORD ActorCount = 0xA0;
	DWORD LocalController = 0x30;

	DWORD ClientSetRotation = 0x638;
	DWORD ClientSetLocation = 0x648;
	DWORD SetIgnoreLookInput = 0x740;
	DWORD GetActorEyesViewPoint = 0x600;
	DWORD ClientReturnToMainMenuWithTextReason = 0xA00;
}

namespace patterns
{
#define S_GWORLD E("48 8B 1D ? ? ? ? 48 85 DB 74 3B 41") 
#define S_OBJECTARRAY E("48 8B 05 ? ? ? ? 4C 8D 34 CD ? ? ? ?") 
#define S_GETNAMEINDEX E("48 89 5C 24 18 55 56 57 48 8B EC 48 83 EC 30 8B 01 48 8B F1") 
#define S_GNAMES E("40 53 48 83 EC 20 48 8B D9 48 85 D2 75 45 33 C0 48 89 01 48 89 ? ? 8D 50 ? E8 ? ? ? ? 8B 53 ? 8D 42 05 89 43 08 3B 43 0C 7E 08 48 8B CB E8 ? ? ? ? 48 8B 0B 48 ? ? ? ? ? ? 41 B8 0A ? ? ? E8 ? ? ? ? 48 8B C3 48 83 C4 20 5B C3 48 8B 42 18") 
#define S_FREE E("48 85 C9 74 2E 53 48 83 EC 20 48 8B D9 48 8B 0D ? ? ? ? 48 85 C9 75 0C") 
#define S_BONEMATRIX E("48 8B C4 55 53 56 57 41 54 41 56 41 57 48 8D 68 A1 48 81 EC E0 00 00 00 0F 29 78 B8") 
#define S_GETACTORBOUNDS E("48 89 5C 24 08 57 48 83 EC 50 48 8B 01 80 F2 01 49 8B F8") 
#define S_PROJECTWORLDTOSCREEN E("48 83 EC 28 E8 ? ? ? ? 48 83 C4 28 C3") 
#define S_LINEOFSIGHTTO E("40 55 53 56 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 E0 49")
#define S_GETVIEWPOINT E("40 55 53 57 41 56 41 57 48 8B EC 48 83 EC 40 48 8B 81 18 07 00 00 4D 8B F8")

	void init()
	{
		std::vector<std::string> errors;
		bool trigger = false;
		uintptr_t base = (uintptr_t)SpoofCall(GetModuleHandleA, (LPCSTR)Fortnite);

#ifdef debug

		OBJECTARRAY = sigscan(Fortnite, S_OBJECTARRAY);
		if (!OBJECTARRAY) errors.push_back(E("Object Array PTR")); else OBJECTARRAY = (uintptr_t)RVA(OBJECTARRAY, 7);

		GWORLD = sigscan(Fortnite, S_GWORLD);
		if (GWORLD) GWORLD = (uintptr_t)RVA(GWORLD, 7); else errors.push_back(E("GWORLD PTR"));

		LOST = sigscan(Fortnite, S_LINEOFSIGHTTO);
		if (!LOST) errors.push_back(E("Line Of Sight To FUNCTION"));

		FREE = sigscan(Fortnite, S_FREE);
		if (!FREE) errors.push_back(E("Free FUNCTION"));

		PROJECTWORLDTOSCREEN = sigscan(Fortnite, S_PROJECTWORLDTOSCREEN, 15);
		if (!PROJECTWORLDTOSCREEN) errors.push_back(E("Project World To Screen FUNCTION"));

		BONEMATRIX = sigscan(Fortnite, S_BONEMATRIX);
		if (!BONEMATRIX) errors.push_back(E("Bone Matrix FUNCTION"));

		GETACTORBOUNDS = (sigscan(Fortnite, S_GETACTORBOUNDS));
		if (!GETACTORBOUNDS) errors.push_back(E("Get Actor Bounds FUNCTION"));

		GETNAME = sigscan(Fortnite, S_GNAMES);
		if (!GETNAME) errors.push_back(E("Get Object Name FUNCTION"));
        
        GETNAMEINDEX = sigscan(Fortnite, S_GETNAMEINDEX);
		if (!GETNAMEINDEX) errors.push_back(E("Get Object Name Index FUNCTION"));

	//	GETVIEWPOINT = sigscan(Fortnite, S_GETVIEWPOINT);
//if (!GETVIEWPOINT) errors.push_back(E("Get View Point FUNCTION"));

#else
		GWORLD = sigscan(Fortnite, S_GWORLD);
		if (GWORLD && bisvalidaddy((uintptr_t)GWORLD)) GWORLD = (uintptr_t)RVA(GWORLD, 7); else errors.push_back(E("GWORLD PTR"));

		LOST = base + offsets::LOST;
		if (!LOST || !bisvalidaddy((uintptr_t)LOST)) errors.push_back(E("Line Of Sight To FUNCTION"));

		FREE = base + offsets::FREE;
		if (!FREE || !bisvalidaddy((uintptr_t)FREE)) errors.push_back(E("Free FUNCTION"));

		PROJECTWORLDTOSCREEN = base + offsets::PROJECTWORLDTOSCREEN;
		if (!PROJECTWORLDTOSCREEN || !bisvalidaddy((uintptr_t)PROJECTWORLDTOSCREEN)) errors.push_back(E("Project World To Screen FUNCTION"));

		BONEMATRIX = base + offsets::BONEMATRIX;
		if (!BONEMATRIX || !bisvalidaddy((uintptr_t)BONEMATRIX)) errors.push_back(E("Bone Matrix FUNCTION"));

		GETACTORBOUNDS = base + offsets::GETACTORBOUNDS;
		if (!GETACTORBOUNDS || !bisvalidaddy((uintptr_t)GETACTORBOUNDS)) errors.push_back(E("Get Actor Bounds FUNCTION"));

		GETNAME = base + offsets::GETNAME;
		if (!GETNAME || !bisvalidaddy((uintptr_t)GETNAME)) errors.push_back(E("Get Object Name FUNCTION"));

#endif

		std::cout << E("\n") << std::endl;

		for (std::string error : errors)
		{
			trigger = true;
			std::cout << E("[-] \"") << error << E("\" Was Not Found!") << std::endl;
		}

		if (trigger)
		{
			std::cout << E("\n\n[!!!] Exitting In 10 Seconds!") << std::endl;
			iat(Sleep)(10000);
			iat(exit)(1);
		}
	}

	void otherdump()
	{
#ifdef debug

        FortUpdater* UPDATER = new FortUpdater();
        if (UPDATER->Init(OBJECTARRAY, GETNAME, GETNAMEINDEX, FREE))
        {
			offsets::PersistentLevel = UPDATER->FindOffset(E("World"), E("PersistentLevel"));
			offsets::GameInstance = UPDATER->FindOffset(E("World"), E("OwningGameInstance"));
			offsets::LocalPlayersArray = UPDATER->FindOffset(E("GameInstance"), E("LocalPlayers"));
			offsets::AcknowledgedPawn = UPDATER->FindOffset(E("PlayerController"), E("AcknowledgedPawn"));
			offsets::PlayerState = UPDATER->FindOffset(E("Pawn"), E("PlayerState"));
			offsets::TeamIndex = UPDATER->FindOffset(E("FortPlayerStateAthena"), E("TeamIndex"));
			offsets::Mesh = UPDATER->FindOffset(E("Character"), E("Mesh"));
			offsets::CustomTimeDilation = UPDATER->FindOffset(E("Actor"), E("CustomTimeDilation"));
			offsets::RootComponent = UPDATER->FindOffset(E("Actor"), E("RootComponent"));
			offsets::RelativeLocation = UPDATER->FindOffset(E("SceneComponent"), E("RelativeLocation"));
			offsets::ComponentVelocity = UPDATER->FindOffset(E("SceneComponent"), E("ComponentVelocity"));
        }
        else
        {
            MessageBoxA(0, E("Console Updater Failed!"), E("Interstellar"), 0);
        }

		uintptr_t base = (uintptr_t)SpoofCall(GetModuleHandleA, (LPCSTR)Fortnite);

		std::cout << E("\n\n//------OFFSET DUMP------") << std::endl;

		std::cout << E("DWORD LOST = 0x") << std::uppercase << std::hex << (uintptr_t)LOST - base << E(";") << std::endl;
		std::cout << E("DWORD FREE = 0x") << std::uppercase << std::hex << (uintptr_t)FREE - base << E(";") << std::endl;
		std::cout << E("DWORD PROJECTWORLDTOSCREEN = 0x") << std::uppercase << std::hex << (uintptr_t)PROJECTWORLDTOSCREEN - base << E(";") << std::endl;
		std::cout << E("DWORD BONEMATRIX = 0x") << std::uppercase << std::hex << (uintptr_t)BONEMATRIX - base << E(";") << std::endl;
		std::cout << E("DWORD GETACTORBOUNDS = 0x") << std::uppercase << std::hex << (uintptr_t)GETACTORBOUNDS - base << E(";") << std::endl;
		std::cout << E("DWORD GETNAME = 0x") << std::uppercase << std::hex << (uintptr_t)GETNAME - base << E(";") << std::endl;
		std::cout << E("\nDWORD PersistentLevel = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::PersistentLevel << E(";") << std::endl;
		std::cout << E("DWORD GameInstance = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::GameInstance << E(";") << std::endl;
		std::cout << E("DWORD LocalPlayersArray = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::LocalPlayersArray << E(";") << std::endl;
		std::cout << E("DWORD AcknowledgedPawn = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::AcknowledgedPawn << E(";") << std::endl;
		std::cout << E("DWORD PlayerState = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::PlayerState << E(";") << std::endl;
		std::cout << E("DWORD TeamIndex = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::TeamIndex << E(";") << std::endl;
		std::cout << E("DWORD Mesh = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::Mesh << E(";") << std::endl;
		std::cout << E("DWORD CustomTimeDilation = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::CustomTimeDilation << E(";") << std::endl;
		std::cout << E("DWORD RootComponent = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::RootComponent << E(";") << std::endl;
		std::cout << E("DWORD RelativeLocation = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::RelativeLocation << E(";") << std::endl;
		std::cout << E("DWORD ComponentVelocity = 0x") << std::uppercase << std::hex << (uintptr_t)offsets::ComponentVelocity << E(";") << std::endl;
	
		std::cout << E("//------OFFSET DUMP------") << std::endl;

#endif //debug
	}
}
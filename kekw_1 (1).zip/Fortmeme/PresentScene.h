#pragma once
#include "Prodigal_Common.h"
#include "font.h"
#include "main.h"

ID3D11RenderTargetView* rendertarget;
ID3D11DeviceContext* context;
ID3D11Device* device;
WNDPROC windowhook_orig;

HRESULT(*Present_Original)(IDXGISwapChain* swap, UINT sync, UINT flag);

bool firsttime = false;
bool mmaim = true;
bool memaim = false;
extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT __stdcall windowhook(HWND hwnd, UINT msg, WPARAM param, LPARAM lparam)
{
	if (msg == WM_KEYUP && param == VK_INSERT)
	{
		settings::menuopen = !settings::menuopen;
		ImGui::GetIO().MouseDrawCursor = settings::menuopen;
	}

	if (msg == WM_KEYUP && param == VK_F2)
		settings::dbg = !settings::dbg;

	if (settings::menuopen)
	{
		ImGui_ImplWin32_WndProcHandler(hwnd, msg, param, lparam);
		return 1;
	}

	return SpoofCall(CallWindowProcA, windowhook_orig, hwnd, msg, param, lparam);
}

void style()
{
	ImGuiStyle& style = ImGui::GetStyle();
	style.WindowRounding = 5.3f;
	style.FrameRounding = 2.3f;
	style.ScrollbarRounding = 0;

	style.Colors[ImGuiCol_Text] = ImVec4(0.90f, 0.90f, 0.90f, 0.90f);
	style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
	style.Colors[ImGuiCol_WindowBg] = ImVec4(0.09f, 0.09f, 0.15f, 1.00f);
	style.Colors[ImGuiCol_ChildWindowBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style.Colors[ImGuiCol_PopupBg] = ImVec4(0.05f, 0.05f, 0.10f, 0.85f);
	style.Colors[ImGuiCol_Border] = ImVec4(0.70f, 0.70f, 0.70f, 0.65f);
	style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style.Colors[ImGuiCol_FrameBg] = ImVec4(0.00f, 0.00f, 0.01f, 1.00f);
	style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.90f, 0.80f, 0.80f, 0.40f);
	style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.90f, 0.65f, 0.65f, 0.45f);
	style.Colors[ImGuiCol_TitleBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.83f);
	style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.40f, 0.40f, 0.80f, 0.20f);
	style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.00f, 0.00f, 0.00f, 0.87f);
	style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.01f, 0.01f, 0.02f, 0.80f);
	style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.20f, 0.25f, 0.30f, 0.60f);
	style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.55f, 0.53f, 0.55f, 0.51f);
	style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.56f, 0.56f, 0.56f, 1.00f);
	style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.56f, 0.56f, 0.56f, 0.91f);
	style.Colors[ImGuiCol_CheckMark] = ImVec4(0.90f, 0.90f, 0.90f, 0.83f);
	style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.70f, 0.70f, 0.70f, 0.62f);
	style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.30f, 0.30f, 0.30f, 0.84f);
	style.Colors[ImGuiCol_Button] = ImVec4(0.48f, 0.72f, 0.89f, 0.49f);
	style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.50f, 0.69f, 0.99f, 0.68f);
	style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.80f, 0.50f, 0.50f, 1.00f);
	style.Colors[ImGuiCol_Header] = ImVec4(0.30f, 0.69f, 1.00f, 0.53f);
	style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.44f, 0.61f, 0.86f, 1.00f);
	style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.38f, 0.62f, 0.83f, 1.00f);
	style.Colors[ImGuiCol_Column] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
	style.Colors[ImGuiCol_ColumnHovered] = ImVec4(0.70f, 0.60f, 0.60f, 1.00f);
	style.Colors[ImGuiCol_ColumnActive] = ImVec4(0.90f, 0.70f, 0.70f, 1.00f);
	style.Colors[ImGuiCol_ResizeGrip] = ImVec4(1.00f, 1.00f, 1.00f, 0.85f);
	style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(1.00f, 1.00f, 1.00f, 0.60f);
	style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(1.00f, 1.00f, 1.00f, 0.90f);
	style.Colors[ImGuiCol_CloseButton] = ImVec4(0.50f, 0.50f, 0.90f, 0.50f);
	style.Colors[ImGuiCol_CloseButtonHovered] = ImVec4(0.70f, 0.70f, 0.90f, 0.60f);
	style.Colors[ImGuiCol_CloseButtonActive] = ImVec4(0.70f, 0.70f, 0.70f, 1.00f);
	style.Colors[ImGuiCol_PlotLines] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
	style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.00f, 0.00f, 1.00f, 0.35f);
	style.Colors[ImGuiCol_ModalWindowDarkening] = ImVec4(0.20f, 0.20f, 0.20f, 0.35f);

	style.AntiAliasedFill = true;
	style.AntiAliasedLines = true;
	style.WindowMinSize = ImVec2(400, 600);
}

ImGuiWindow& BeginScene() {
	ImGui_ImplDX11_NewFrame();
	ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
	ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
	ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
	ImGui::Begin(E("##scene"), nullptr, ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoTitleBar);

	auto& io = ImGui::GetIO();
	ImGui::SetWindowPos(ImVec2(0, 0), ImGuiCond_Always);
	ImGui::SetWindowSize(ImVec2(io.DisplaySize.x, io.DisplaySize.y), ImGuiCond_Always);

	return *ImGui::GetCurrentWindow();
}

VOID EndScene(ImGuiWindow& window) {
	window.DrawList->PushClipRectFullScreen();
	ImGui::PopStyleColor();
	ImGui::PopStyleVar(2);
	ImGui::Render();
}

void set()
{
	if (memaim)
	{
		mmaim = false;
		settings::aimtype = 1;
	}
	if (mmaim)
	{
		memaim = false;
		settings::aimtype = 0;
	}

	if (settings::corneresp)
		settings::boxesp = false;

	if (settings::boxesp)
		settings::corneresp = false;
}

HRESULT PresentScene(IDXGISwapChain* a1, UINT a2, UINT a3)
{
	tr

	if (!device)
	{
		ID3D11Texture2D* backBuffer = 0;
		ID3D11Texture2D* renderTarget = nullptr;
		D3D11_TEXTURE2D_DESC backBufferDesc = { 0 };

		a1->GetDevice(__uuidof(device), reinterpret_cast<PVOID*>(&device));

		device->GetImmediateContext(&context);
		a1->GetBuffer(0, __uuidof(renderTarget), reinterpret_cast<PVOID*>(&renderTarget));

		device->CreateRenderTargetView(renderTarget, nullptr, &rendertarget);
		renderTarget->Release();

		a1->GetBuffer(0, __uuidof(ID3D11Texture2D), (PVOID*)&backBuffer);
		backBuffer->GetDesc(&backBufferDesc);

		hwnd = SpoofCall(FindWindowA, (LPCSTR)E("UnrealWindow"), (LPCSTR)E("Fortnite  "));
		if (!firsttime)
		{
			windowhook_orig = reinterpret_cast<WNDPROC>(SpoofCall(SetWindowLongPtrW, hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(windowhook)));
			SmallText = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(fortnite_compressed_data, fortnite_compressed_size, 15.f);
			MediumText = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(fortnite_compressed_data, fortnite_compressed_size, 23.f);
			LargeText = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedTTF(fortnite_compressed_data, fortnite_compressed_size, 40.f);
			firsttime = true;
		}

		X = (float)backBufferDesc.Width;
		Y = (float)backBufferDesc.Height;
		backBuffer->Release();

		ImGui_ImplDX11_Init(hwnd, device, context);
		ImGui_ImplDX11_CreateDeviceObjects();
	}

	if (hsv > 255)
		hsv = 0;
	else
		hsv += 1;

	context->OMSetRenderTargets(1, &rendertarget, nullptr);
	auto& windowshit = BeginScene();

	windowshit.DrawList->AddRectFilled(ImVec2(0, 0), ImVec2(X, Y), ImGui::GetColorU32({ 0.f, 0.f, 0.f, alpha / 255.f }), 0.f);

	Prodigal::main(windowshit);

	windowshit.DrawList->AddCircle(ImVec2(X / 2, Y / 2), settings::fov - 1, ImGui::GetColorU32({ 0.f, 0.f, 0.f, 1.f }), 30, 1.f);
	windowshit.DrawList->AddCircle(ImVec2(X / 2, Y / 2), settings::fov + 1, ImGui::GetColorU32({ 0.f, 0.f, 0.f, 1.f }), 30, 1.f);
	windowshit.DrawList->AddCircle(ImVec2(X / 2, Y / 2), settings::fov, ImColor::HSV(hsv / 255.f, 1, 1), 30, 1.5f);

	ImGui::PushFont(LargeText);
	drawoutlinetext(windowshit, E("Alienware HVH Fortnite"), ImVec2(70, 70), ImColor::HSV(hsv / 255.f, 1, 1));
	ImGui::PopFont();

	ImGui::PushFont(SmallText);
	if (settings::menuopen)
	{
		if (alpha <= 120)
			alpha += 10;

		style();

		ImGui::Begin(E("Menu "), (bool*)false, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);

#pragma region titlething

		ImGui::Text(E(""));
		ImGui::Text(E("                                     "));
		ImGui::SameLine();
		ImGui::PushFont(LargeText);
		ImGui::Text(E("Alienware"));
		ImGui::PopFont();
		ImGui::SameLine();
		ImGui::PushFont(SmallText);
		ImGui::Text(E("V0.1.4"));
		ImGui::PopFont();

#pragma endregion titlething

		ImGui::Text(E(""));
		ImGui::Text(E(""));

#pragma region menu

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Checkbox(E("  Mouse Aimbot (Legit)"), &mmaim);
		ImGui::PopFont();

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Checkbox(E("  Memory Aimbot (Rage)"), &memaim);
		ImGui::PopFont();

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Checkbox(E("  Visible Check"), &settings::vischeck);
		ImGui::PopFont();

		ImGui::Text(E(""));

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Checkbox(E("  Box ESP"), &settings::boxesp);
		ImGui::PopFont();

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Checkbox(E("  Corner ESP"), &settings::corneresp);
		ImGui::PopFont();

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Checkbox(E("  Snaplines ESP"), &settings::snapline);
		ImGui::PopFont();

		ImGui::Text(E(""));

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Text(E("ESP Color            "));
		ImGui::PopFont();
		ImGui::SameLine();
		ImGuiStyle& style = ImGui::GetStyle();
		style.WindowMinSize = ImVec2(220, 290);
		ImGui::ColorEdit4(E("  ESP Color Picker"), settings::espcolor, ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoInputs);


		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Text(E("Snaplines Color   "));
		ImGui::PopFont();
		ImGui::SameLine();
		ImGui::ColorEdit4(E("  Snaplines Color Picker"), settings::snaplinecolor, ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoInputs);


		ImGui::Text(E(""));

		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::PushFont(MediumText);
		ImGui::Text(((std::string)E("Aimbot FOV                             ") + std::to_string((int)settings::fov).c_str()).c_str());
		ImGui::PopFont();
		ImGui::Text(E("        "));
		ImGui::SameLine();
		ImGui::SliderFloat(E(" "), &settings::fov, 0, 1000, "%.f", 1.f, ImVec2(20, 30), ImColor::HSV(hsv / 255.f, 1, 1));

#pragma endregion menu


		ImGui::End();
	}
	else
		alpha = 0;
	ImGui::PopFont();

	set();

	EndScene(windowshit);

	return SpoofCall(Present_Original, a1, a2, a3);
	ca
}
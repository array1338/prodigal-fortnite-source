#pragma once
#include "Prodigal_Common.h"
#include "lazyimporter.h"
#include "xorstr.hpp"

template <typename Ret, typename... Args>
Ret SpoofCall(Ret(*fn)(Args...), Args... args);

uintptr_t pTrampoline = 0;

namespace _SpoofCallInternal
{
    extern "C" PVOID RetSpoofStub();

    template <typename Ret, typename... Args>
    inline Ret Wrapper(PVOID shell, Args... args) {
        auto fn = (Ret(*)(Args...))(shell);
        return fn(args...);
    }

    template <std::size_t Argc, typename>
    struct Remapper {
        template<typename Ret, typename First, typename Second, typename Third, typename Fourth, typename... Pack>
        static Ret Call(PVOID shell, PVOID shell_param, First first, Second second, Third third, Fourth fourth, Pack... pack) {
            return Wrapper<Ret, First, Second, Third, Fourth, PVOID, PVOID, Pack...>(shell, first, second, third, fourth, shell_param, nullptr, pack...);
        }
    };

    template <std::size_t Argc>
    struct Remapper<Argc, std::enable_if_t<Argc <= 4>> {
        template<typename Ret, typename First = PVOID, typename Second = PVOID, typename Third = PVOID, typename Fourth = PVOID>
        static Ret Call(PVOID shell, PVOID shell_param, First first = First{}, Second second = Second{}, Third third = Third{}, Fourth fourth = Fourth{}) {
            return Wrapper<Ret, First, Second, Third, Fourth, PVOID, PVOID>(shell, first, second, third, fourth, shell_param, nullptr);
        }
    };
}


#define Fortnite E("FortniteClient-Win64-Shipping.exe")

#define in_range(x, a, b) (x >= a && x <= b)
#define get_bits(x) (in_range((x & (~0x20)), 'A', 'F') ? ((x & (~0x20)) - 'A' + 0xA): (in_range(x, '0', '9') ? x - '0': 0))
#define get_byte(x) (get_bits(x[0]) << 4 | get_bits(x[1]))
uintptr_t sigscan(std::string module, std::string pattern, int times = 0)
{
    uintptr_t moduleAdress = 0;

    if (!pTrampoline)
    {
        if (strstr(module.c_str(), Fortnite))
            moduleAdress = (uintptr_t)GetModuleHandleA((const char*)0);
        else
            moduleAdress = (uintptr_t)GetModuleHandleA(module.c_str());
    }
    else
    {
        if (strstr(module.c_str(), Fortnite))
            moduleAdress = (uintptr_t)SpoofCall(GetModuleHandleA, (const char*)0);
        else
            moduleAdress = (uintptr_t)SpoofCall(GetModuleHandleA, module.c_str());
    }

    static auto patternToByte = [](const char* pattern)
    {
        auto       bytes = std::vector<int>{};
        const auto start = const_cast<char*>(pattern);
        const auto end = const_cast<char*>(pattern) + strlen(pattern);

        for (auto current = start; current < end; ++current)
        {
            if (*current == '?')
            {
                ++current;
                if (*current == '?')
                    ++current;
                bytes.push_back(-1);
            }
            else { bytes.push_back(strtoul(current, &current, 16)); }
        }
        return bytes;
    };

    const auto dosHeader = (PIMAGE_DOS_HEADER)moduleAdress;
    const auto ntHeaders = (PIMAGE_NT_HEADERS)((std::uint8_t*)moduleAdress + dosHeader->e_lfanew);

    const auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;
    auto       patternBytes = patternToByte(pattern.c_str());
    const auto scanBytes = reinterpret_cast<std::uint8_t*>(moduleAdress);

    const auto s = patternBytes.size();
    const auto d = patternBytes.data();

    size_t nFoundResults = 0;

    for (auto i = 0ul; i < sizeOfImage - s; ++i)
    {
        bool found = true;
        for (auto j = 0ul; j < s; ++j)
        {
            if (scanBytes[i + j] != d[j] && d[j] != -1)
            {
                found = false;
                break;
            }
        }
        if (found)
        {
            if (times != 0)
            {
                if (nFoundResults < times)
                {
                    nFoundResults++;                                   // Skip Result To Get nSelectResultIndex.
                    found = false;                                     // Make sure we can loop again.
                }
                else
                {
                    return reinterpret_cast<uintptr_t>(&scanBytes[i]);  // Result By Index.
                }
            }
            else
            {
                return reinterpret_cast<uintptr_t>(&scanBytes[i]);      // Default/First Result.
            }
        }
    }
    return NULL;
}



template <typename Ret, typename... Args>
Ret SpoofCall(Ret(*fn)(Args...), Args... args)
{
    if (!pTrampoline)
        pTrampoline = sigscan(Fortnite, E("FF 27"), 5);
    struct
    {
        PVOID Trampoline;
        PVOID Function;
        PVOID Reg;
    } params = {
        (PVOID)pTrampoline,
        reinterpret_cast<void*>(fn),
    };

    return _SpoofCallInternal::Remapper<sizeof...(Args), void>::template Call<Ret, Args...>(&_SpoofCallInternal::RetSpoofStub, &params, args...);
}
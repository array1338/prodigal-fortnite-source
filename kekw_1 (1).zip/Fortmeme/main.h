#pragma once
#include "Prodigal_Common.h"
#include <list>

namespace Prodigal
{
	bool main(ImGuiWindow& window)
	{

		for (auto Player : Players)
		{
			if (Controller.AcknowledgedPawn().bisvalid())
			if (Player.PawnName() == Controller.AcknowledgedPawn().PawnName()) continue;

			Vector3 Head = Player.GetBoneLocation(eBone::BONE_HEAD);
			Vector3 HeadW2S = Controller.WorldToScreen(Head);
			Vector3 Bottom = Controller.WorldToScreen(Player.GetBoneLocation(eBone::BONE_NULL_1));
			Vector3 Head_10 = Controller.WorldToScreen(Vector3(Head.x, Head.y, Head.z + 10));

			if (Head.x == 0 && Head.y == 0) continue;
			if (HeadW2S.x == 0 && HeadW2S.y == 0) continue;
			if (Bottom.x == 0 && Bottom.y == 0) continue;
			if (Head_10.x == 0 && Head_10.y == 0) continue;

			float Height = Head_10.y - Bottom.y;
			Height = SpoofCall(fabsf, Height);
			float Width = Height * 0.5f;
			Head_10.x = Head_10.x - (Width / 2);

			if (settings::skeletonesp)
			{
				std::list<std::list<int>> Skeleton = { upper_part, right_arm, left_arm, spine, lower_right, lower_left };
				Vector3 neckpos = Player.GetBoneLocation(eBone::BONE_NECK);
				Vector3 pelvispos = Player.GetBoneLocation(eBone::BONE_PELVIS_1);
				if (neckpos.x != 0 && neckpos.y != 0 && pelvispos.x != 0 && pelvispos.y != 0)
				{
					Vector3 previous(0, 0, 0);
					Vector3 current, prev, cur;
					for (auto a : Skeleton)
					{
						previous = Vector3(0, 0, 0);
						for (int bone : a)
						{
							current = bone == eBone::BONE_NECK ? neckpos : (bone == eBone::BONE_PELVIS_1 ? pelvispos : Player.GetBoneLocation(bone));
							if (previous.x == 0.f)
							{
								previous = current;
								continue;
							}
							prev = Controller.WorldToScreen(previous);
							cur = Controller.WorldToScreen(current);
							if (prev.x != 0 && prev.y != 0 && cur.x != 0 && cur.y != 0)
								window.DrawList->AddLine(ImVec2(prev.x, prev.y), ImVec2(cur.x, cur.y), ESPCOL, 1.5f);
							previous = current;
						}
					}
				}
			}

			if (settings::snapline)
				window.DrawList->AddLine(ImVec2(HeadW2S.x, Bottom.y), ImVec2(X / 2, Y), SNAPCOL);

			if (settings::boxesp)
			{
				window.DrawList->AddLine(ImVec2(Head_10.x, Head_10.y), ImVec2(Head_10.x + Width, Head_10.y), ESPCOL);
				window.DrawList->AddLine(ImVec2(Head_10.x, Head_10.y), ImVec2(Head_10.x, Head_10.y + Height), ESPCOL);
				window.DrawList->AddLine(ImVec2(Head_10.x + Width, Head_10.y), ImVec2(Head_10.x + Width, Head_10.y + Height), ESPCOL);
				window.DrawList->AddLine(ImVec2(Head_10.x, Head_10.y + Height), ImVec2(Head_10.x + Width, Head_10.y + Height), ESPCOL);
			}
			else if (settings::corneresp)
			{
				float Width_3 = (Width / 3);
				float Height_3 = (Height / 3);
				window.DrawList->AddLine(ImVec2(Head_10.x, Head_10.y), ImVec2(Head_10.x, Head_10.y + Height_3), ESPCOL);
			}

			if (settings::vischeck)
				if (!Controller.BisVisible(Player.GetRaw())) continue;

			auto x = HeadW2S.x - (X / 2);
			auto y = HeadW2S.y - (Y / 2);
			if (distance < settings::fov && distance < OldDist)
			{
				AimW2S = HeadW2S;
			}
		}

		if (iskeypressed(VK_RBUTTON) && AimW2S.x != 0 && AimW2S.y != 0)
		{
			if (settings::aimtype == 0)
				mousemove(AimW2S.x, AimW2S.y, X, Y, 5);
		}
	}
}
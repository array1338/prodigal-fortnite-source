#pragma once
#include "Prodigal_Common.h"

namespace GetPresent
{
    auto GetPresentAddress() -> std::pair<uintptr_t, std::string>
    {
        uintptr_t Discord = (uintptr_t)SpoofCall(GetModuleHandleA, (LPCSTR)E("DiscordHook64.dll"));
        uintptr_t Dxgi = (uintptr_t)SpoofCall(GetModuleHandleA, (LPCSTR)E("dxgi.dll"));

        if (Discord && Dxgi)
        {
            uintptr_t OriginalDxgiPresent = sigscan(E("dxgi.dll"), E("48 89 5C 24 ? 48 89 74 24 ? 55 57 41 56 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 60"));
            if (OriginalDxgiPresent)
                return { OriginalDxgiPresent, E("OriginalDiscord_DXGI::PresentScene") };
            else
            {
                uintptr_t DiscordDxgiPresent = sigscan(E("dxgi.dll"), E("E9 ? ? ? ? 48 89 74 24 20 55 57"));
                if (DiscordDxgiPresent)
                    return { DiscordDxgiPresent, E("DiscordHooked_DXGI::PresentScene") };
            }
        }

        if (Dxgi)
        {
            uintptr_t OriginalDxgiPresent = sigscan(E("dxgi.dll"), E("48 89 5C 24 10 48 89 74 24 20 55 57 41 56 48 8D 6C 24 90"));
            if (OriginalDxgiPresent)
                return { OriginalDxgiPresent, E("Original_DXGI::PresentScene") };
        }

        return { 0, E("ERROR NO USABLE PRESENT SCENE FOUND!") };
    }
}
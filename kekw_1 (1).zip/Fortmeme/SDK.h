#pragma once
#include "structs.h"
#include "Offsets_Sigs.h"

namespace SDK
{
	class PlayerPawn
	{
	public:

		FVector GetRootLocation()
		{
			PVOID RootComponent = *(PVOID*)((PBYTE)this + offsets::RootComponent);
			if (!RootComponent)
				return { 0,0,0 };

			FVector RelativeLocation = *(FVector*)((PBYTE)RootComponent + offsets::RelativeLocation);

			return RelativeLocation;
		}

		PVOID GetMesh()
		{
			PVOID Mesh = *(PVOID*)((PBYTE)this + offsets::Mesh);
			if (!Mesh)
				return 0;

			return Mesh;
		}

		Vector3 GetBoneLocation(int bone)
		{
			PVOID Mesh = GetMesh();
			if (!Mesh) Vector3(0, 0, 0);

			auto GetBoneMatrix = ((FMatrix * (__fastcall*)(PVOID, FMatrix*, int))(BONEMATRIX));

			SpoofCall(GetBoneMatrix, Mesh, myMatrix, bone);

			return Vector3(myMatrix->M[3][0], myMatrix->M[3][1], myMatrix->M[3][2]);
		}

		PVOID GetPlayerState()
		{
			PVOID State = *(PVOID*)((PBYTE)this + offsets::PlayerState);
			if (State && bisvalidaddy((uintptr_t)State))
				return State;
			else
				return 0;
		}

		void SetPlayerState(PVOID State)
		{
			PVOID A = *(PVOID*)((PBYTE)this + offsets::PlayerState);
			if (A && bisvalidaddy((uintptr_t)A))
				*(PVOID*)((PBYTE)this + offsets::PlayerState) = State;
		}

		PVOID GetRaw()
		{
			return (PVOID)this;
		}
	};

	class PlayerPawnsWrapper
	{
	public:


		bool bisvalid()
		{
			return bisvalidaddy((uintptr_t)GetRaw());
		}

		bool bisvalid2()
		{
			return bisvalidaddy((uintptr_t)GetRaw()) && bisvalidaddy((uintptr_t)PlayerState());
		}

	private:
		PlayerPawn* Player;
	};


	class Controller
	{
	public:

		bool BisVisible(PVOID Actor)
		{
			Vector3 null = { 0,0,0 };

			auto LineOfSightTo = ((BOOL(__fastcall*)(PVOID, PVOID, Vector3*))(LOST));
			return SpoofCall(LineOfSightTo, (PVOID)this, Actor, &null);
		}

		void ClientSetRotation(Vector3 Rotation)
		{
			auto ClientSetRotation = (*(void(__fastcall**)(PVOID, Vector3, char))(*(PVOID*)((PBYTE)this + offsets::ClientSetRotation)));
			ClientSetRotation((PVOID)this, Rotation, (char)0);
		}

		Vector3 WorldToScreen(Vector3 World)
		{
			FVector A = { World.x, World.y, World.z };
			FVector B = { 0 };

			auto ProjectWorldToScreen = ((bool(__fastcall*)(PVOID, FVector, FVector*, char))(PROJECTWORLDTOSCREEN));

			if (!SpoofCall(ProjectWorldToScreen, (PVOID)this, A, &B, (char)0))
				return Vector3(0, 0, 0);
			else
				return Vector3(B.X, B.Y, B.Z);
		}
		PVOID GetRaw()
		{
			return (PVOID)this;
		}
	};

	class ControllerWrapper
	{
	public:

		void ClientSetRotation(Vector3 Rotation)
		{
			LocalController->ClientSetRotation(Rotation);
		}

		Vector3 WorldToScreen(Vector3 World)
		{
			return LocalController->WorldToScreen(World);
		}

		bool BisVisible(PVOID Pawn)
		{
			return LocalController->BisVisible(Pawn);
		}

		void KickPlayer(char reason)
		{
			LocalController->KickPlayer(reason);
		}
	private:
		Controller* LocalController;
	};

	class Actor
	{
	public:
		std::string GetName()
		{
			return getobjectname((PVOID)this);
		}

		FVector GetRootLocation()
		{
			PVOID RootComponent = *(PVOID*)((PBYTE)this + offsets::RootComponent);
			if (!RootComponent)
				return { 0,0,0 };

			FVector RelativeLocation = *(FVector*)((PBYTE)RootComponent + offsets::RelativeLocation);

			return RelativeLocation;
		}

		PVOID GetRaw()
		{
			return (PVOID)this;
		}
	};

	class ActorWrapper
	{
	public:
		ActorWrapper(DWORD_PTR ActorArray)
		{
			ActorArr = ActorArray;
			pawn = 0;
			valid = false;
		}

		std::string Name()
		{
			return pawn->GetName();
		}

		FVector RootLocation()
		{
			return pawn->GetRootLocation();
		}

		bool BIsPlayerPawn()
		{
			if (strstr(ActorName.c_str(), E("PlayerPawn_Athena_C"))) return true;
			else return false;
		}

		void Index(int index)
		{
			PVOID Pawn = *(PVOID*)((PBYTE)ActorArr + (index * 8));
			if (Pawn)
			{
				valid = true;
				pawn = (Actor*)Pawn;
			}
			else
				valid = false;
		}

		bool bisvalid()
		{
			if (!bisvalidaddy(ActorArr) || !valid) return false;
			else return true;
		}

		PVOID GetRaw()
		{
			return pawn->GetRaw();
		}

	private:
		Actor* pawn;
		bool valid;
		DWORD_PTR ActorArr;
	};

	class GameInstance
	{
	public:
		ControllerWrapper GetController()
		{

			PVOID ControllerA = *(PVOID*)((PBYTE)LocalPlayer + offsets::LocalController);
			if (!ControllerA) return 0;

			return ControllerWrapper((Controller*)ControllerA);
		}

		PVOID GetRaw()
		{
			return (PVOID)this;
		}
	};


	class GameInstanceWrapper
	{
	public:

		bool bisvalid()
		{
			return bisvalidaddy((uintptr_t)GetRaw());
		}

	private:
		GameInstance* GameInstanceA;
	};


	class PersistentLevel
	{
	public:
		ActorWrapper GetAActors()
		{
			DWORD_PTR AACTORS = *(DWORD_PTR*)((PBYTE)this + offsets::ActorArray);
			if (!AACTORS && !bisvalidaddy(AACTORS)) return 0;

			return ActorWrapper(AACTORS);
		}

	};


	class PersistentLevelWrapper
	{
	public:
		PersistentLevelWrapper(PersistentLevel* Persis)
		{
			Persislevel = Persis;
		}

		ActorWrapper ActorArray()
		{
			return Persislevel->GetAActors();
		}

		int ActorCount()
		{
			return Persislevel->GetActorCount();
		}

	private:
		PersistentLevel* Persislevel;
	};


	class UWorld
	{
	public:

		GameInstanceWrapper GetGameInstance()
		{
			PVOID GameInstancev = *(PVOID*)((PBYTE)this + offsets::GameInstance);
			if (!GameInstancev) return 0;

			return GameInstanceWrapper((GameInstance*)GameInstancev);
		}

		PersistentLevelWrapper GetPersistentLevel()
		{
			DWORD_PTR PersistentLvl = *(DWORD_PTR*)((PBYTE)this + offsets::PersistentLevel);
			if (!PersistentLvl) return 0;

			return PersistentLevelWrapper((PersistentLevel*)PersistentLvl);
		}

		PVOID GetRaw()
		{
			return (PVOID)this;
		}
	};

	class UWorldWrapper
	{
	public:
		UWorldWrapper(uintptr_t World)
		{
			GWORLDS = (UWorld*)(*(PVOID*)World);
		}

		GameInstanceWrapper GameInstance()
		{
			return GWORLDS->GetGameInstance();
		}

		PVOID GetRaw()
		{
			return GWORLDS->GetRaw();
		}

		bool bisvalid()
		{
			return bisvalidaddy((uintptr_t)GetRaw());
		}

	private:
		UWorld* GWORLDS;
	};
}

void ReInitializeGWORLD()
{
	GWORLD = sigscan(Fortnite, S_GWORLD);
	if (GWORLD) GWORLD = (uintptr_t)RVA(GWORLD, 7);
}

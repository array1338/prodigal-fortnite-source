#pragma once
#include "Prodigal_Common.h"
#include "lazyimporter.h"
#include "scanner.h"

#define M_PI 3.14159265358979323846264338327950288419716939937510

uintptr_t GWORLD = 0;
uintptr_t GETNAME = 0;
uintptr_t GETNAMEINDEX = 0;
uintptr_t OBJECTARRAY = 0;
uintptr_t FREE = 0;
uintptr_t BONEMATRIX = 0;
uintptr_t GETACTORBOUNDS = 0;
uintptr_t PROJECTWORLDTOSCREEN = 0;
uintptr_t PROCESSEVENT = 0;
uintptr_t LOST = 0;
uintptr_t GETVIEWPOINT = 0;


HWND hwnd;

typedef int (WINAPI* LPFN_MBA)(DWORD);
static LPFN_MBA keypress;

#define read(base, offs) (*(PVOID*)(((PBYTE)base + offs)))

template<class T>
struct TArray
{
	friend struct FString;

public:
	inline TArray()
	{
		Data = nullptr;
		Count = Max = 0;
	};

	inline int Num() const
	{
		return Count;
	};

	inline T& operator[](int i)
	{
		return Data[i];
	};

	inline const T& operator[](int i) const
	{
		return Data[i];
	};

	inline bool IsValidIndex(int i) const
	{
		return i < Num();
	}

private:
	T* Data;
	int32_t Count;
	int32_t Max;
};


struct FString : private TArray<wchar_t>
{
	inline FString()
	{
	};

	FString(const wchar_t* other)
	{
		Max = Count = *other ? SpoofCall(std::wcslen, other) + 1 : 0;

		if (Count)
		{
			Data = const_cast<wchar_t*>(other);
		}
	};

	inline bool IsValid() const
	{
		return Data != nullptr;
	}

	inline const wchar_t* c_str() const
	{
		return Data;
	}

	std::string ToString() const
	{
		auto length = std::wcslen(Data);

		std::string str(length, '\0');

		std::use_facet<std::ctype<wchar_t>>(std::locale()).narrow(Data, Data + length, '?', &str[0]);

		return str;
	}
};

struct FName
{
	int ComparisonIndex;
	int Number;
};

typedef struct 
{
	float X, Y, Z;
} FVector;

class Vector3
{
public:
	Vector3() : x(0.f), y(0.f), z(0.f)
	{

	}

	Vector3(float _x, float _y, float _z) : x(_x), y(_y), z(_z)
	{

	}
	~Vector3()
	{

	}

	float x;
	float y;
	float z;

	inline float Dot(Vector3 v)
	{
		return x * v.x + y * v.y + z * v.z;
	}

	inline float Distance(Vector3 v)
	{
		auto A = SpoofCall(powf, (float)v.x - x, (float)2.0);
		auto B = SpoofCall(powf, (float)v.y - y, (float)2.0);
		auto C = SpoofCall(powf, (float)v.z - z, (float)2.0);
		return float(SpoofCall(sqrtf, A + B + C));
	}

	inline Vector3 ClampAngles() {

		if (x < -180.0f)
			x += 360.0f;

		if (x > 180.0f)
			x -= 360.0f;

		if (y < -74.0f)
			y = -74.0f;

		if (y > 74.0f)
			y = 74.0f;

		return Vector3(x, y, 0);
	}

	inline double Length() {
		return SpoofCall(sqrtf, x * x + y * y + z * z);
	}

	Vector3 operator+(Vector3 v)
	{
		return Vector3(x + v.x, y + v.y, z + v.z);
	}

	Vector3 operator-(Vector3 v)
	{
		return Vector3(x - v.x, y - v.y, z - v.z);
	}

	Vector3 operator*(float flNum) { return Vector3(x * flNum, y * flNum, z * flNum); }
};


struct FRotator
{
	float Pitch;
	float Yaw;
	float Roll;
};

struct ClientSetLocation_Params
{
	FVector DestLoc;
	FRotator DestRot;
	bool returnvalue;
};

struct K2_TeleportTo_Params
{
	FVector DestLoc;
	FRotator DestRot;
	bool returnvalue;
};

struct FBox
{
	Vector3  Min;
	Vector3  Max;
	unsigned char IsValid;
	unsigned char UnknownData01[0x3];
};

struct FMinimalViewInfo
{
	Vector3 Loc;
	Vector3 Rot;
	float Fov;
};

struct FMatrix
{
	float M[4][4];
};

class FText {
	public:
	char _padding_[0x28];
	PWCHAR Name;
	DWORD Length;

	inline char* c_str()
	{
		char sBuff[255];
		wcstombs((char*)sBuff, (const wchar_t*)this->Name, sizeof(sBuff));
		return sBuff;
	}
};

static FMatrix* myMatrix = new FMatrix();

bool bisvalidaddy(uintptr_t address)
{
	if (!SpoofCall(IsBadReadPtr, (const void*)address, (UINT_PTR)8)) 
		return true;
	else 
		return false;
}

void freememory(__int64 thing)
{
	auto free_f = ((__int64(__fastcall*)(__int64))(FREE));
	__try 
	{
		SpoofCall(free_f, thing);
	} __except(EXCEPTION_EXECUTE_HANDLER) {}
}

std::string getobjectname(PVOID actor)
{
	FString A;
	std::string B = "";
	auto getobjectname_f = ((FString*(__fastcall*)(FString* str, PVOID actor))(GETNAME));
	SpoofCall(getobjectname_f, &A, actor);
	B = A.ToString();
	if (A.c_str() != 0)
		freememory((__int64)A.c_str());
	return B;
}

std::string getobjectnameindex(int index)
{
	FString A;
	std::string B = "";
	auto getobjectname_f = ((FString*(__fastcall*)(int* index, FString* out))(GETNAMEINDEX));
	SpoofCall(getobjectname_f, &index, &A);
	B = A.ToString();
	if (A.c_str() == 0)
		return E("");
	freememory((__int64)A.c_str());
	return B;
}

void CallProcessEvent(PVOID* OBJECTTARGET, PVOID FUNCTION, PVOID* PARAM)
{
	auto processevent_f = ((__int64(__fastcall*)(PVOID*, PVOID, PVOID*))(PROCESSEVENT));
	if (!processevent_f || !bisvalidaddy((uintptr_t)processevent_f))
		return;
	SpoofCall(processevent_f, OBJECTTARGET, FUNCTION, PARAM);
}

bool ClientSetLocationA(PVOID Actor, FVector Location, FRotator Rotation)
{
	ClientSetLocation_Params Params;
	Params.DestLoc = Location;
	Params.DestRot = Rotation;
	CallProcessEvent(&Actor, 0, (PVOID*)&Params);
	return Params.returnvalue;
}

FBox getbox(PVOID actor)
{
	FBox NewBox;
	NewBox.IsValid = false;
	NewBox.Max = Vector3(0, 0, 0);
	NewBox.Min = Vector3(0, 0, 0);
	Vector3 orgin(0,0,0);
	Vector3 boxextend(0, 0, 0);
	auto getactorbounds_f = ((void(__fastcall*)(PVOID, char, Vector3*, Vector3*))(GETACTORBOUNDS));
	SpoofCall(getactorbounds_f, actor, (char)true, &orgin, &boxextend);
	NewBox.IsValid = 1;
	NewBox.Min = orgin - boxextend;
	NewBox.Max = orgin + boxextend;
	return NewBox;
}

bool iskeypressed(DWORD key)
{
	if (SpoofCall(keypress, key))
		return true;
	else
		return false;
}

void mousemove(float tarx, float tary, float X, float Y, int smooth)
{
	float ScreenCenterX = (X / 2);
	float ScreenCenterY = (Y / 2);
	float TargetX = 0;
	float TargetY = 0;

	if (tarx != 0)
	{
		if (tarx > ScreenCenterX)
		{
			TargetX = -(ScreenCenterX - tarx);
			TargetX /= smooth;
			if (TargetX + ScreenCenterX > ScreenCenterX * 2) TargetX = 0;
		}

		if (tarx < ScreenCenterX)
		{
			TargetX = tarx - ScreenCenterX;
			TargetX /= smooth;
			if (TargetX + ScreenCenterX < 0) TargetX = 0;
		}
	}

	if (tary != 0)
	{
		if (tary > ScreenCenterY)
		{
			TargetY = -(ScreenCenterY - tary);
			TargetY /= smooth;
			if (TargetY + ScreenCenterY > ScreenCenterY * 2) TargetY = 0;
		}

		if (tary < ScreenCenterY)
		{
			TargetY = tary - ScreenCenterY;
			TargetY /= smooth;
			if (TargetY + ScreenCenterY < 0) TargetY = 0;
		}
	}
	SpoofCall(mouse_event, (DWORD)MOUSEEVENTF_MOVE, (DWORD)TargetX, (DWORD)TargetY, (DWORD)0, (ULONG_PTR)0);
}

enum eBone
{
	BONE_NULL_1 = 0,
	BONE_NULL_2 = 1,
	BONE_PELVIS_1 = 2,
	BONE_PELVIS_2 = 3,
	BONE_PELVIS_3 = 4,
	BONE_TORSO = 5,

	BONE_CHEST_LOW = 6,
	BONE_CHEST = 7,

	// -------------------------

	BONE_CHEST_LEFT = 8,

	BONE_L_SHOULDER_1 = 9,
	BONE_L_ELBOW = 10,

	BONE_L_HAND_ROOT_1 = 11,

	BONE_L_FINGER_1_ROOT = 12,
	BONE_L_FINGER_1_LOW = 13,
	BONE_L_FINGER_1 = 14,
	BONE_L_FINGER_1_TOP = 15,

	BONE_L_FINGER_2_ROOT = 16,
	BONE_L_FINGER_2_LOW = 17,
	BONE_L_FINGER_2 = 18,
	BONE_L_FINGER_2_TOP = 19,

	BONE_L_FINGER_3_ROOT = 20,
	BONE_L_FINGER_3_LOW = 21,
	BONE_L_FINGER_3 = 22,
	BONE_L_FINGER_3_TOP = 23,

	BONE_L_FINGER_4_ROOT = 24,
	BONE_L_FINGER_4_LOW = 25,
	BONE_L_FINGER_4_ = 26,
	BONE_L_FINGER_4_TOP = 27,

	BONE_L_THUMB_ROOT = 28,
	BONE_L_THUMB_LOW = 29,
	BONE_L_THUMB = 30,

	BONE_L_HAND_ROOT_2 = 31,
	BONE_L_WRIST = 32,
	BONE_L_ARM_LOWER = 33,

	BONE_L_SHOULDER_2 = 34,

	BONE_L_ARM_TOP = 35,

	// -------------------------

	BONE_CHEST_TOP_1 = 36,

	// -------------------------

	BONE_CHEST_RIGHT = 37,

	BONE_R_ELBOW = 38,

	BONE_R_HAND_ROOT_1 = 39,

	BONE_R_FINGER_1_ROOT = 40,
	BONE_R_FINGER_1_LOW = 41,
	BONE_R_FINGER_1 = 42,
	BONE_R_FINGER_1_TOP = 43,

	BONE_R_FINGER_2_ROOT = 44,
	BONE_R_FINGER_2_LOW = 45,
	BONE_R_FINGER_2 = 46,
	BONE_R_FINGER_2_TOP = 47,

	BONE_R_FINGER_3_ROOT = 48,
	BONE_R_FINGER_3_LOW = 49,
	BONE_R_FINGER_3 = 50,
	BONE_R_FINGER_3_TOP = 51,

	BONE_R_FINGER_4_ROOT = 52,
	BONE_R_FINGER_4_LOW = 53,
	BONE_R_FINGER_4_ = 54,
	BONE_R_FINGER_4_TOP = 55,

	BONE_R_THUMB_ROOT = 56,
	BONE_R_THUMB_LOW = 57,
	BONE_R_THUMB = 58,

	BONE_R_HAND_ROOT = 59,
	BONE_R_WRIST = 60,
	BONE_R_ARM_LOWER = 61,

	BONE_R_SHOULDER = 62,

	BONE_R_ARM_TOP = 63,

	// -------------------------

	BONE_CHEST_TOP_2 = 64,

	BONE_NECK = 65,
	BONE_HEAD = 66,

	// -------------------------

	BONE_L_LEG_ROOT = 67,
	BONE_L_KNEE = 68,
	BONE_L_FOOT_ROOT = 69,
	BONE_L_SHIN = 70,
	BONE_L_FOOT_MID = 71,
	BONE_L_FOOT_LOW = 72,
	BONE_L_THIGH = 73,

	// -------------------------

	BONE_R_LEG_ROOT = 74,
	BONE_R_KNEE = 75,
	BONE_R_FOOT_ROOT = 76,
	BONE_R_SHIN = 77,
	BONE_R_FOOT_MID = 78,
	BONE_R_FOOT_LOW = 79,
	BONE_R_THIGH = 80,

	// -------------------------

	BONE_NULL_3 = 81,
	BONE_MISC_L_FOOT = 82,
	BONE_MISC_R_FOOT = 83,
	BONE_NULL_4 = 84,
	BONE_MISC_R_HAND_1 = 85,
	BONE_MISC_L_HAND = 86,
	BONE_MISC_R_HAND_2 = 87,
};
#pragma once
#include "Prodigal_Common.h"


namespace settings
{
	/// <summary>
	/// 0 = Mouse Aim
	/// 1 = Memory Aim
	/// </summary>
	int aimtype = 0;

	bool snapline = true;

	bool boxesp = false;

	bool corneresp = true;

	bool menuopen = false;

	bool vischeck = false;

	bool skeletonesp = true;

	bool dbg = false;

	float fov = 300;

	float espcolor[4] = { 1.f, 0, 0, 1.f };
	float snaplinecolor[4] = { 0.f, 0.2f, 0.5f, 1.f };
}
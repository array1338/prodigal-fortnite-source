//#define debug
#pragma once
#include <windows.h>
#include <fstream>
#include <iostream>
#include <string>
#include <D3DX11.h>
#include <vector>

#include "SDK.h"
#include "structs.h"
#include "xorstr.hpp"
#include "MinHook.h"
#include "Offsets_Sigs.h"
#include "lazyimporter.h"
#include "scanner.h"
#include "GetPresent.h"
#include "settings.h"
#include "FortUpdater.h"

#include <imgui.h>
#include <imgui_impl_dx11.h>
#include <imgui_internal.h>

int X, Y, alpha, hsv;
ImFont* SmallText;
ImFont* MediumText;
ImFont* LargeText;

#define tr try {
#define ca } catch (...) {}

void drawoutlinetext(ImGuiWindow& windowshit, std::string str, ImVec2 loc, ImU32 colr, bool centered = false)
{
	ImVec2 size = { 0,0 };
	float minx = 0;
	float miny = 0;
	if (centered)
	{
		size = ImGui::GetFont()->CalcTextSizeA(windowshit.DrawList->_Data->FontSize, 0x7FFFF, 0, str.c_str());
		minx = size.x / 2.f;
		miny = size.y / 2.f;
	}

	windowshit.DrawList->AddText(ImVec2((loc.x - 1) - minx, (loc.y - 1) - miny), ImGui::GetColorU32({ 0.f, 0.f, 0.f, 1.f }), str.c_str());
	windowshit.DrawList->AddText(ImVec2((loc.x + 1) - minx, (loc.y + 1) - miny), ImGui::GetColorU32({ 0.f, 0.f, 0.f, 1.f }), str.c_str());
	windowshit.DrawList->AddText(ImVec2((loc.x + 1) - minx, (loc.y - 1) - miny), ImGui::GetColorU32({ 0.f, 0.f, 0.f, 1.f }), str.c_str());
	windowshit.DrawList->AddText(ImVec2((loc.x - 1) - minx, (loc.y + 1) - miny), ImGui::GetColorU32({ 0.f, 0.f, 0.f, 1.f }), str.c_str());
	windowshit.DrawList->AddText(ImVec2(loc.x - minx, loc.y - miny), colr, str.c_str());
}

void log(std::string str)
{
#ifdef debug
	std::cout << str << std::endl;
#endif
}
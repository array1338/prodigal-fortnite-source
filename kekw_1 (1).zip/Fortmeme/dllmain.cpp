#include "Prodigal_Common.h"
#include "PresentScene.h"

void init()
{
    log(E("[+] Hello World!"));

    log(E("[+] Checking If dxgi.dll Is Loaded!"));


#ifdef debug
    std::cout << E("[+] dxgi.dll Loaded, Base Address Of Module: 0x") << std::hex << Dxgi_Base << E("!") << std::endl;
#endif

    log(E("[+] Loading Hooking Library!"));

    auto err = MH_Initialize();
    if (err != MH_OK)
    {
        std::cout << E("Hook Init Failed With Error: \"") << MHSTATUSTOSTR(err) << E("\"\nContact Support!\n[!!!] Exitting In 10 Seconds!") << std::endl;
        iat(Sleep)(10000);
        iat(exit)(1);
    }

    log(E("[+] Hook Init Completed Successfully!"));

    log(E("[+] Scanning For Suitable Present Scene Addresses In Memory!"));

    auto [presentaddy, presenttype] = GetPresent::GetPresentAddress();

    if (!presentaddy)
    {
        std::cout << E("[-] No Suitable Present Scene Found!\n[!!!] Exitting In 10 Seconds!") << std::endl;
        iat(Sleep)(10000);
        iat(exit)(1);
    }

    log(E("[+] Using \"") + presenttype + E("\" For Rendering"));

    HMODULE Win32U = 0;
    Win32U = SpoofCall(GetModuleHandleA, (LPCSTR)E("win32u.dll"));
    if (!Win32U)

    keypress = (LPFN_MBA)SpoofCall(GetProcAddress, Win32U, (LPCSTR)E("NtUserGetAsyncKeyState"));
    if (!keypress)
    {
        std::cout << E("[-] Failed To Get KeyBind Internal!\n[!!!] Exitting In 10 Seconds!") << std::endl;
        iat(Sleep)(10000);
        iat(exit)(1);
    }

    auto status = MH_CreateHook((void*)presentaddy, (void*)PresentScene, (void**)&Present_Original);
    status = MH_EnableHook((void*)presentaddy);
    status = MH_QueueEnableHook((void*)presentaddy);

    if (status != MH_OK)
    {
        std::cout << E("Render Hook Failed With Error: \"") << MHSTATUSTOSTR(status) << E("\" Using Type: \"") << presenttype << E("\"\nContact Support!\n[!!!] Exitting In 10 Seconds!") << std::endl;
        iat(Sleep)(10000);
        iat(exit)(1);
    }
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    SpoofCall(DisableThreadLibraryCalls, hModule);
    if (ul_reason_for_call == DLL_PROCESS_ATTACH)
    {

#ifdef debug
        SpoofCall(AllocConsole);
        SpoofCall(freopen, (LPCSTR)E("CONIN$"), (LPCSTR)E("r"), stdin);
        SpoofCall(freopen, (LPCSTR)E("CONOUT$"), (LPCSTR)E("w"), stdout);
        SpoofCall(freopen, (LPCSTR)E("CONOUT$"), (LPCSTR)E("w"), stderr);
#endif debug

        init();
    }
    return TRUE;
}